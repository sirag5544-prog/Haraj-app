package com.harajsudan.app;
import android.app.Activity; import android.content.Intent; import android.net.Uri; import android.os.Bundle;
import android.webkit.*; import android.view.*;
public class MainActivity extends Activity {
 WebView w; ValueCallback<Uri[]> cb; static final int PICK=1001;
 public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); setContentView(w);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
  w.setWebViewClient(new WebViewClient());
  w.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> c,FileChooserParams p){
   if(cb!=null)cb.onReceiveValue(null); cb=c; try{startActivityForResult(p.createIntent(),PICK);}catch(Exception e){cb=null;return false;} return true;}});
  w.loadUrl("file:///android_asset/index.html");
 }
 protected void onActivityResult(int r,int c,Intent d){if(r==PICK&&cb!=null){cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));cb=null;}super.onActivityResult(r,c,d);}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
