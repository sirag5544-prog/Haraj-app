# بناء APK سحابي — حراج السودان

## الطريقة
1. أنشئ حسابًا في GitHub من الهاتف.
2. أنشئ مستودعًا جديدًا (Repository) باسم `haraj-sudan`.
3. ارفع محتويات هذا المشروع إلى المستودع، بما فيها مجلد `.github`.
4. افتح تبويب **Actions**.
5. اختر **Build Haraj Sudan APK**.
6. اضغط **Run workflow**.
7. بعد انتهاء البناء، افتح نتيجة التشغيل ثم قسم **Artifacts**.
8. حمّل `Haraj-Sudan-debug-apk.zip` وافتحه على الهاتف.
9. فك الضغط وثبّت `app-debug.apk`.

## ملاحظات
- هذه نسخة Debug للتجربة على الهاتف.
- للنشر في Google Play نحتاج لاحقًا توقيع Release وإنشاء AAB.
- قبل تشغيل التطبيق، نفّذ `supabase/schema.sql` في Supabase SQL Editor.
- لا تضع Service Role Key في المشروع.
