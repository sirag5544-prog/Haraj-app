# تشغيل حراج السودان — النسخة المتصلة

1. افتح Supabase > SQL Editor.
2. نفّذ الملف `supabase/schema.sql` كاملاً.
3. افتح مجلد المشروع `Haraj_Sudan_Connected_v2` في Android Studio.
4. اعمل Gradle Sync ثم Run.

تم ربط النسخة الحالية بـ Supabase للمصادقة، قراءة الإعلانات، إضافة الإعلانات، ورفع الصور.
استخدم التطبيق Publishable Key فقط؛ لا تضع Service Role Key داخل Android.
